# DFLG Investments – Registro de decisões do projeto

Última atualização: 27/10/2026 (terceiro zip do dia, com o dashboard; testado)

Este arquivo é a memória oficial do projeto. Quem for retomar o trabalho (pessoa ou IA, em um chat novo) deve ler este arquivo primeiro, junto com o documento do PI, o código e o `PROMPT_CLAUDE.md`.

Convenção desta versão: **[código]** = conferido lendo o código do zip; **[testado]** = executado com PHP e banco de verdade; **[relato]** = informado por outra conversa, não conferido de novo; **[PDF]** = conferido no documento do PI (versão enviada em 26/10/2026, arquivo `Modelo_de_documentação_do_PI_TDS_-_2026-7.pdf`, enviado em 27/10/2026).

Base desta atualização: o terceiro zip enviado pelo responsável em 27/10/2026 (`1793215369032_DFLG.zip`), com o **dashboard (RF 07)** incluído, lido e **testado de verdade** (PHP 8.3 e MariaDB 10.11, com requisições HTTP reais; resumo na seção 7). Novidades em relação ao segundo zip: o **dashboard com gráficos (RF 07)** e três ajustes pedidos nas últimas conversas já aplicados (correção do chefe no `script.sql`, link "Categorias" de volta no menu e confirmação ao clicar em "Sair"). O que já vinha do zip de 26/10: **RF 01 e RF 02** (painel administrativo, `nivel_permissao`, chefe), troca de senha, campo `telefone` e edição do perfil (RF 04) com e-mail e data de nascimento travados para o usuário comum. **Todos os 15 RF e a home page (Figura 8) estão no código, a home feita no mesmo dia (2.17).**

## 1. Regras de trabalho

1. O **documento do PI é a fonte da verdade**. O sistema deve ser 100% baseado nele.
2. **Capítulos 1 e 2 estão congelados.** O capítulo 3 (diagramas) também, em princípio.
3. Só se altera o documento quando algo está realmente errado, e **quem define o que está errado é apenas o responsável pelo projeto**. A IA só aponta e pergunta, nunca decide sozinha.
4. **Nada de inventar** requisito, regra ou funcionalidade que não esteja no documento. Se algo estiver ambíguo ou ausente, perguntar antes de implementar.
5. **Não mexer no que o responsável não pediu.** Itens que ele decidiu manter como estão não são reabertos.
6. Toda entrega cita o RF, a RN ou o UC a que corresponde, e separa o que vem do documento do que é suposição.
7. **Entrega de código:** um RF por vez; enviar só os arquivos alterados e dizer o que mudou em cada um; seguir 100% o padrão de código que já existe no projeto; avisar antes de qualquer biblioteca, comando, arquivo ou padrão novo.
8. Dizer sempre o que foi **testado de verdade** e o que foi só **lido**.
9. Ao entregar arquivos, preservar o fim de linha de cada um (vários usam CRLF, outros LF). **Antes de escrever ou entregar qualquer coisa, comparar o zip mais recente do responsável com o que a IA tem**: o responsável também altera o projeto por conta própria (ou por outro chat), e a IA nunca deve sobrescrever o trabalho dele. Exemplos: o ícone do botão de excluir conta e a implementação do ranking e do aporte em metas já feitos por ele.

## 2. Decisões fechadas

### 2.1 Correções do documento (a aplicar pelo grupo)

Conferido no PDF de 26/10/2026:

| # | Onde | Alteração | Situação no PDF |
|---|---|---|---|
| 1 | Seção 3.2.1 (cenário Registrar Ganho) | UC-09 e RF 09 viram UC-07 e RF 07. | Aplicada. |
| 2 | Seção 3.2.1 | RN 05, FE 01 e campo Valor dizem "maior que zero". | Aplicada. |
| 3 | Seção 2.3.2 | RF14 vira **RF04** (perfil). | Aplicada (o PDF agora diz "perfil do usuário (RF04)"). |
| 4 | Seção 2.3.1 | Referência à seção 3.3 vira 2.3.3. | Aplicada. |
| 5 | Quadro 3, RN 13 | Nova redação (ver 2.2). | Aplicada, com a frase opcional. |
| 6 | Seção 3.4 (Figura 7) e Figura 6 | Refazer o DER e manter o diagrama de classes consistente. | **Parcial.** Os textos da 3.3 e da 3.4 já citam `historico_xp`, `maior_streak`, `foto` e `status`, mas as **figuras 6 e 7 continuam antigas** (ver seção 3, item DER). |

Itens de redação que continuam abertos no PDF (ver também a seção 3): a seção 2.3 remete à 2.1 para falar de redes sociais, mas a 2.1 não trata disso; o Resumo ainda diz que ranking e sequências estão "previstos para as próximas etapas"; os capítulos 4 e 5 ainda têm o texto-guia do modelo no lugar do conteúdo; a referência da REVISTA ARCO repete "Acesso em:"; ANDERSON (2010) e PRESSMAN; MAXIM (2016) estão nas referências mas não são citados no texto.

Itens que estavam abertos e já estão resolvidos no PDF: a Lista de Ilustrações inclui a Figura 7; o texto do RF dentro do cenário do UC é igual ao RF 07 do Quadro 2; a seção 2.3.2 cita RF04; a RN 11 foi reescrita sem o verbo repetido; o termo "simulador" foi trocado por "calculadoras de investimento" no texto (o Quadro 1, a 2.1, a RN 07, o Quadro 5 e a 2.3.3 já usam "calculadoras"; só a imagem do protótipo da Figura 12 ainda mostra "Usou simulador de investimentos").

### 2.2 RN 13 (parcelamentos): redação aplicada no PDF

> Todo parcelamento deve possuir uma quantidade de parcelas maior que 1, um valor de parcela maior que zero e a data de vencimento da primeira parcela informada, podendo esta ser anterior, igual ou posterior à data atual. As parcelas com vencimento até a data atual são consideradas pagas.

### 2.3 Modelo de parcelamento (decisão B) – implementado; o diagrama se ajusta ao código

> **Atualizado em 03/11 (ver 2.19):** a opção "lançar parcelas futuras" saiu. As parcelas passam a ser lançadas uma a uma pelo botão "Lançar parcela", e "pagas" passa a ser "lançadas". O texto abaixo descreve o modelo anterior; o que mudou está na 2.19.

**Como está no código [código]:**

- `parcelamentos` tem `id` próprio e os campos `usuario_id`, `categoria_id`, `descricao`, `valor_total`, `quantidade_parcelas`, `parcelas_pagas`, `data_primeira_parcela`, `tag`, `valor_parcela`, `lancar_futuros`.
- `registro_financeiro.parcelamento_id` aponta para `parcelamentos.id`. Cada parcela é uma despesa em `registro_financeiro`.
- **Parcelas pagas** é derivado: contagem de registros do parcelamento com `data_registro <= hoje`. A coluna `parcelas_pagas` da tabela ficou gravada com 0 e **não é usada**.
- **Saldo, totais, evolução mensal e extratos (RF 11)** só contam registros com `data_registro <= hoje`.
- Ao editar, as parcelas futuras são apagadas (`data_registro > hoje`) e refeitas.
- Excluir apaga as despesas geradas e o parcelamento; a edição e a criação usam transação com try/catch.
- `tag` e `lancar_futuros` seguem o diagrama de classes.
- A categoria "Metas" não pode ser usada em parcelamento (reservada aos aportes, ver 2.12). [código]

**Relatado como testado em outra conversa [relato]:** compra de 5x de R$ 100 iniciada há 2 meses gera 5 despesas e 3 parcelas pagas; editar valor preserva as vencidas e refaz só as futuras; com "lançar futuros" desligado existe só a 1ª parcela; excluir apaga as despesas geradas; parcelamento de outro usuário não é acessível.

**Decisão do responsável: vale o código.** O diagrama de classes ligava `registro_financeiro` e `parcelamentos` como 1 para 0..1 (com `id_registro` como chave de `parcelamentos`). O código faz um parcelamento gerar vários registros (`registro_financeiro.parcelamento_id` aponta para `parcelamentos.id`). O diagrama e o DER é que se ajustam ao código: `parcelamentos` ganha `id` próprio, `id_usuario_comum`, `id_categoria`, `descricao`, `valor_total` e `data_primeira_parcela`; a associação passa a ser 1 parcelamento para 0..* registros (1 usuario_comum para 0..* parcelamentos). A coluna `parcelas_pagas` não entra (é derivada). No banco, `parcelamento_id` não tem chave estrangeira declarada no `script.sql`. Sem mudança de código.

**Pontos conhecidos, sem decisão:**

- ~~Reduzir a quantidade abaixo do que já venceu deixa o dado estranho ("3 pagas de 2").~~ **Resolvido em 03/11 (2.18):** a quantidade não pode ficar abaixo das parcelas já pagas e a data da 1ª parcela não pode mais ser editada. [testado]
- ~~Com "lançar futuros" desligado, não havia forma de lançar as parcelas seguintes.~~ **Resolvido em 03/11 (2.19):** a opção saiu e cada parcela é lançada pelo botão.
- ~~A lista de transações filtra "até hoje", então parcelas futuras não aparecem nela.~~ Não se aplica mais (2.19): não existe parcela com data futura.
- ~~Apagar à mão uma parcela gerada não é bloqueado.~~ **Resolvido em 03/11 (2.19):** editar e excluir parcela pela tela de Transações é bloqueado.
- ~~A exclusão do parcelamento abre transação sem try/catch.~~ **Resolvido em 03/11 (2.19):** agora tem `try/catch` com `rollBack()`. Texto antigo: a exclusão do parcelamento abria transação sem try/catch. **Testado [testado] com falha forçada no meio (gatilho no banco):** o sistema responde 503 com a tela de erro e **nada se perde** (os 3 registros e o parcelamento continuam), porque a conexão cai e o MySQL desfaz a transação aberta. Ou seja, funciona, mas por rollback implícito; um `try/catch` com `rollBack()` explícito deixaria o código mais correto (opcional).

### 2.4 XP e gamificação (decisão C) – implementado

- O documento está certo e o modelo se ajustou a ele.
- **Tabela `historico_xp`** (`usuario_id`, `acao`, `xp`, `data_concessao`, `criado_em`). Cada concessão gera uma linha. As regras de frequência e os rankings semanal e mensal usam essa tabela. O PDF (seção 3.3) descreve os atributos com outros nomes (`id_usuario_comum`, `pontos`, `data_registro`); conferir ao refazer o DER.
- **Marcos de streak (leitura A):** cada marco (7, 30, 100 e 1.000 dias) dá XP uma única vez na vida.
- **Ações e pontos (Quadro 5), como estão no `GamificacaoService`:** acesso diário 5 (por dia); marcos 25, 100, 300 e 5.000 (únicos); perfil completo 20 (único); calculadoras 10 (por dia, RN 07; no código e no `historico_xp` a ação se chama `simulador`, é só nome interno); preferências 10 (único); relatórios 15 (único, **conectado ao RF 11**).
- **Preferências:** salvar o formulário de preferências do Perfil (visibilidade no ranking e modo escuro) concede os 10 XP uma única vez. Administrador não tem registro em `usuario_comum` e por isso não ganha XP, sem gerar erro. [testado]
- **Registrar receitas, despesas, metas, aportes em metas ou parcelamentos não gera XP** (seções 2.3.1 e 2.3.3). Aportes confirmados sem XP. [testado]
- **Concessão atômica:** histórico e total de XP são gravados na mesma transação.
- **Streak (RF 09):** contada quando o usuário abre o dashboard; incrementa em dia consecutivo e reinicia se pular um dia (RN 03). O `streak_atual` gravado ainda **só muda quando o usuário abre o dashboard**, mas agora o que aparece e o que desempata usam o **streak efetivo** (RN 03): vale o número gravado se o último acesso foi hoje ou ontem, senão é 0. O Perfil mostra `getStreakEfetivo()` e o ranking usa o mesmo cálculo em SQL. [código]
- **Fórmula de nível:** XP para o próximo nível = nível atual × 100.

### 2.5 Exclusão de conta (RF 15 e RN 14) – implementado

- Só o **usuário comum** exclui a própria conta (RF 15). Administrador é redirecionado ao perfil nas rotas de exclusão, e o botão "Excluir Conta" não aparece para ele. [testado]
- **RN 14 (confirmação explícita):** validada no servidor. O POST só exclui se vier `confirmarExclusao` com o valor exato `1`; sem o campo ou com o campo vazio, a tela volta com a mensagem e nada é apagado. [testado]
- Na tela de exclusão, o botão fica **cinza e inativo** até marcar "Estou ciente..."; ao marcar, fica **vermelho** e ativo; ao desmarcar, volta a cinza. A tela ainda pede o `confirm()` do navegador ao clicar. Comportamento validado pelo responsável.
- A exclusão apaga o usuário e os dados ligados por chave estrangeira (`ON DELETE CASCADE`).
- Nesta entrega **não** foi criada a regra "último administrador ativo". A RN 09 do documento é a do administrador chefe (ver 2.8).

### 2.6 Modo claro/escuro (RNF 07) – implementado e validado pelo responsável

- **Decisão do responsável:** a escolha fica em coluna nova no banco, na tabela **`usuarios`** (vale para todos, inclusive administrador).
- Coluna `usuarios.tema ENUM('claro','escuro') NOT NULL DEFAULT 'claro'`, no `script.sql` e numa migração no `DatabaseInitializer` (o banco existente recebe a coluna sozinho). [testado]
- O tema é aplicado por um script no `header.php` (`data-bs-theme` no `<html>`), então vale para todas as telas que incluem o header. [testado]
- O `style.css` tem regras escuras para o fundo do `body`, `.bg-light` e `.table-light`.
- Login e cadastro não têm tema (não há usuário logado; já têm fundo preto).
- O interruptor "Modo escuro" fica no cartão Preferências do Perfil, e o cartão aparece também para o administrador.

### 2.7 Decisões do responsável de manter como está

- A coluna `data_ultimo_xp` foi **removida** do banco (substituída por `ultimo_acesso`). Ela aparece no diagrama de classes (seção 3.3) e no texto da 3.4, então precisa sair dos dois no DER refeito.
- A tabela `simulacoes_investimento` (diagrama de classes) não é usada: as calculadoras não gravam simulações.
- A concessão de XP não protege contra dois pedidos simultâneos do mesmo usuário (raro).
- Os nomes dos arquivos de view das calculadoras já foram corrigidos (todos em minúsculas). [código]
- **Avisos "Undefined variable" do VS Code nas views:** o responsável adotou um bloco `@var` no topo de cada view (comentário `/** ... @var mixed $x */`) para silenciar os avisos. É o padrão do projeto daqui para frente em views novas. [código]

### 2.8 Administrador chefe, RF 01 e RF 02 – implementado (zip de 27/10) e testado

**Como está no código [código] e [testado]:**

- `administradores.nivel_permissao` (INT, 1 = chefe, 2 = administrador comum). A migração `migrarNivelPermissao` marca como chefe o administrador **mais antigo** (o do script, `admin@dflg.com`). Campo novo `usuarios.telefone` (opcional, só dígitos, DDD + 8 ou 9 dígitos).
- Regra central (`AdminService::permitido`): ninguém age pelo painel sobre a **própria conta** nem sobre o **chefe** (RN 09); o chefe age sobre administradores e usuários comuns; o administrador comum age **só sobre usuários comuns**. **Criar administrador é exclusivo do chefe** (RN 01), sempre como conta nova nível 2 e sem linha de `usuario_comum` (não há promoção de usuário comum). **Excluir conta é exclusivo do chefe**, com confirmação (RN 14).
- Painel `/admin`: indicadores (usuários comuns: total, ativos e bloqueados; administradores; novos cadastros em 7 e 30 dias; engajamento dos comuns ativos por último acesso: até 7 dias, de 8 a 30, mais de 30). Lista `/admin/usuarios` com busca, filtro de tipo e status e paginação; telas de novo, editar, bloquear, desbloquear e excluir.
- Bloqueio: login recusado, e quem está logado é derrubado **no próximo clique** com aviso (vale também para administrador bloqueado).
- Troca de senha em `/perfil/senha` (senha atual correta, nova diferente da atual, confirmação igual).

**Testado [testado]:** chefe cria administrador; e-mail e nickname repetidos, menor de 16 e telefone inválido rejeitados; administrador comum não abre a tela de criar, não cria por POST direto e não vê a lista de administradores; bloqueia e desbloqueia usuário comum; ninguém bloqueia o chefe nem a própria conta; só o chefe bloqueia administrador comum; exclusão sem confirmação recusada, administrador comum não exclui, chefe não pode ser excluído, chefe exclui usuário comum (e os dados ligados somem); usuário comum não acessa `/admin`.

**Bug encontrado [testado] e já corrigido no zip de 27/10 (terceiro):** em **banco novo** o administrador do script nascia com `nivel_permissao = 2` (o `DEFAULT` da coluna), porque o `script.sql` já cria a coluna e a migração só marcava o chefe quando a coluna ainda não existia; sem chefe, a criação de administrador era recusada. O `INSERT` do `script.sql` agora grava `nivel_permissao = 1`. **Retestado [testado] em banco criado do zero:** o admin do script é chefe (nível 1) e cria administrador normalmente.

**Decisões que o código tomou e que o responsável precisa confirmar (as perguntas que estavam abertas aqui):** o chefe é o administrador do script; o chefe não pode ser bloqueado, excluído nem alterado por outro administrador; só o chefe exclui contas e cria administradores; administrador comum pode bloquear e editar usuários comuns; ninguém age sobre a própria conta pelo painel. **Diferença para o documento:** o RF 02 diz "editar, bloquear, desbloquear", e o código também deixa o chefe **excluir** contas. Os capítulos 1 e 2 estão congelados, então ou se aceita a diferença ou o responsável decide ajustar o texto.

### 2.9 Ambiente

- Windows com XAMPP (Apache 2.4 e PHP 8.2), VS Code e Firefox.
- Projeto em `htdocs/DFLG` (sem espaços no caminho). `URL_BASE` = `http://localhost/DFLG`, com `.htaccess` na raiz do projeto redirecionando para `public/index.php`. Fuso definido como `America/Sao_Paulo`.
- Banco `db_dflg_investments`, criado automaticamente pelo projeto na primeira conexão, a partir do `script.sql`. O `script.sql` não cria nem escolhe o banco (isso é do `DatabaseInitializer`, pelo `DB_NAME`), então também pode ser importado no phpMyAdmin de um hospedeiro, com o banco criado no painel.
- Os testes da IA são feitos com PHP 8.3 e MariaDB 10.11 usando o servidor embutido do PHP, não com o Apache/MySQL do XAMPP, e sem ver as telas renderizadas.
- O PDF do RF 11 precisa da extensão `mbstring` do PHP (ligada por padrão no XAMPP). Se aparecer "undefined function mb_convert_encoding", ativar `extension=mbstring` no `php.ini`.

### 2.10 Relatórios e extrato em PDF (RF 11 e UC-11) – implementado e validado pelo responsável

- **Decisão do responsável:** "gerar" o extrato = **visualizar na tela e baixar em PDF**, com biblioteca nova.
- **Biblioteca:** FPDF 1.84 (licença permissiva), em `app/libs/fpdf/`, sem Composer. Foi escolhida porque o `Autoload.php` do projeto lança exceção para classes fora do namespace `app\`, o que quebraria bibliotecas com autoload próprio (como o Dompdf); o FPDF é carregado por `require_once` em `app/helpers/ExtratoPdf.php`.
- Tela `/relatorios` (abas Extrato mensal e Extrato anual, com seletor de mês e ano) e `/relatorios/pdf` (mesmo extrato em PDF). Link "Relatórios" no menu.
- **Extrato mensal:** saldo no início do mês, receitas, despesas, saldo final e a lista de lançamentos com o saldo depois de cada um (a evolução do saldo). **Extrato anual:** uma linha por mês (só até o mês atual no ano corrente) com receitas, despesas, resultado e saldo acumulado, mais o total do ano.
- **Regra de dados:** só entram registros com `data_registro <= hoje`, igual ao saldo do dashboard. Parcelas futuras ficam de fora.
- **XP:** os 15 XP de relatórios saem na primeira abertura da **tela** (não no PDF), uma única vez. Administrador abre a tela e baixa o PDF sem erro e sem XP. [testado]
- Anos oferecidos: do ano do primeiro registro até o ano atual. Parâmetros inválidos na URL caem no mês atual.
- Limites do PDF: emoji vira `?` (o FPDF não tem emoji); descrição longa é cortada com "..."; o tipo de conteúdo sai como `application/x-download` (padrão do FPDF), e o navegador baixa normalmente.
- **RNF 01 (até 2 s):** com 21 mil registros e um mês com 1.000 lançamentos (PDF de 30 páginas), tudo respondeu em menos de 0,05 s no servidor de teste. [testado]

### 2.11 Ranking (RF 10 e UC-10) – feito pelo responsável, testado

**Decisões do responsável (respondidas nesta sessão):** períodos pelo **calendário** (semana de segunda a domingo; mês do dia 1 ao último dia) e ordenação **literal da RN 10** (nível atual primeiro, depois o XP do período).

**Como está no código [código]:**

- `/ranking` com abas Semanal, Mensal e Geral; padrão **semanal**; período inválido volta ao semanal. Link "Ranking" no menu.
- Mostra os **20 primeiros** (`LIMITE = 20`) com pódio (CSS `.podio`) e tabela. Colunas: posição, apelido (`@nickname`), nível e XP (total no geral; do período nos demais). A linha do próprio usuário recebe o selo "Você".
- Quem está fora do top 20 vê uma caixa "Sua posição: Nº", com nível e XP.
- **Semanal e mensal** somam o XP de `historico_xp` dentro do período; só entra quem ganhou XP nele. **Geral** usa `xp_total` e inclui todos os visíveis, mesmo com 0 XP.
- **Ordem (RN 10):** nível, XP, maior `streak_atual`, `criado_em` mais antigo e `id` (o id só garante uma ordem fixa). A posição do usuário é 1 mais a quantidade de participantes à frente dele, pela mesma ordem.
- Só aparece quem é usuário comum e tem "Aparecer no ranking" ligado. Quem desligou vê "Você está oculto no ranking" com link para o perfil; quem não pontuou no período vê "Você ainda não pontuou neste período"; o administrador não tem aviso nem erro.
- Ver o ranking **não dá XP** (não está no Quadro 5).

**Testado [testado]:** com 73 usuários de teste (empates de nível, XP, streak e cadastro; usuário oculto; limites da semana e do mês), a ordem, os valores e a posição "Sua posição" **bateram com um cálculo independente** em Python nos três períodos, sem erro PHP. Administrador, período inválido e acesso sem login também testados.

**Bloqueados:** na versão anterior o usuário bloqueado aparecia no ranking (no teste, um ficou em 1º lugar). No zip de 26/10 as duas consultas do `RankingRepository` já filtram `u.status = 'ativo'`. [código; não foi executado de novo]

**Streak no desempate:** o `RankingRepository` usa o streak efetivo (ver 2.4), não o número gravado. [código]

### 2.12 Aporte em metas (RF 14, UC-14 e UC-07.5) – feito pelo responsável, testado

**Como está no código [código]:**

- O aporte é uma **despesa** em `registro_financeiro` na categoria **"Metas"**, ligada à meta pela coluna nova `registro_financeiro.meta_id` (FK `ON DELETE CASCADE`). A categoria "Metas" (tipo despesa) é semeada pelo `script.sql` e pela migração `migrarAporteMeta`.
- Telas: botão "Aportar" na lista de metas (some quando a meta está concluída) e `/metas/aportar?id=...`; salva em `POST /metas/aportar/salvar`.
- **Regras do aporte:** valor maior que zero; não passa do que falta para concluir a meta; não passa do saldo; meta concluída não recebe aporte; só o dono da meta aporta. A meta e a despesa são gravadas na **mesma transação**, e o `UPDATE` só soma se ainda couber no valor alvo.
- **Excluir um aporte** (pela lista de transações) devolve o valor à meta e ao saldo (`GREATEST(valor_atual - valor, 0)`), em transação. **Excluir a meta** apaga as despesas dos aportes, e o dinheiro volta ao saldo.
- O aporte **não pode ser editado** (tela e serviço bloqueiam). A categoria "Metas" **não aparece** nos formulários de transação e de parcelamento nem no filtro da lista, e é recusada se alguém tentar usá-la manualmente.
- **Editar a meta não altera mais o `valor_atual`:** ele só muda por aportes (valor enviado à força no POST foi ignorado).
- Aporte **não dá XP**.
- **Valor alvo nunca abaixo do já guardado (03/11, 2.18):** na criação, o "valor já guardado" não pode passar do valor alvo; na edição, o valor alvo não pode ficar abaixo de `valor_atual` (valor inicial + aportes). [testado]
- **"Valor já guardado"** (decisão do responsável: manter **só na criação** da meta): o campo continua em `metas_create.php`, e a edição só mostra o valor, que muda pelos aportes. [código] Ponto fechado.

**Testado [testado]:** receita de R$ 1.000, meta de R$ 500 e meta de R$ 5.000. Aporte válido (meta e saldo corretos, despesa gerada na categoria Metas com data de hoje); valores zero, negativo, texto e vazio recusados com mensagem; saldo insuficiente recusado; completar a meta; meta concluída bloqueada; meta de outro usuário sem efeito; despesa manual na categoria Metas recusada; edição do aporte bloqueada; exclusão de um aporte e da meta devolvendo o saldo; edição forçada de `valorAtual` ignorada; nenhum erro PHP em 21 telas.

### 2.13 Limite mensal por categoria (RF 12, UC-12 e RN 12) – testado em 27/10

**Como está no código [código]:**

- Rotas `GET /categorias` e `POST /categorias/limites` (`CategoriaController`), link "Categorias" no menu, tela `categorias_list.php` com o gasto do mês e um campo de limite (R$) por categoria.
- **Tabela nova `limites_categoria`** (`usuario_id`, `categoria_id`, `valor_limite`, chave única por usuário e categoria, `ON DELETE CASCADE`), criada no `script.sql` e na migração `migrarLimiteCategoria`. As categorias continuam **globais** (iguais para todos); o limite é de cada usuário.
- Só entram categorias de **despesa**, e a categoria "Metas" fica de fora. O gasto é o do **mês atual** (dia 1 ao último dia), contando só despesas com `data_registro <= hoje` (parcela futura não conta, como no saldo). **Gastar exatamente o limite não excede**; excede quem passa dele.
- **Salvar:** campo vazio remove o limite; o valor precisa ser numérico, maior que zero e caber em DECIMAL(10,2) (até 99.999.999,99). Se algum campo for inválido, **nada é gravado**. A gravação é uma transação com try/catch.
- **RN 12 (notificar):** alerta vermelho "Limite mensal excedido" (`partials/alerta_limites.php`), com categoria, gasto, limite e excesso, no **dashboard, na lista de transações e na lista de parcelamentos**.
- A coluna `categorias.limite_orcamento` continua no banco e no model, sem uso.

**Testado [testado]:** limite salvo; alerta no dashboard, nas transações e nos parcelamentos com categoria, gasto, limite e excesso (R$ 300,00 de R$ 200,00, R$ 100,00 acima); gastar exatamente o limite não alerta e passar de R$ 0,01 alerta; despesa futura e de mês anterior não contam; excluir a despesa tira o alerta; um usuário não vê o alerta do outro; valor `abc`, `0`, `-5` e `100000000` rejeitados sem gravar nada; campo vazio remove o limite; categoria de receita, `Metas` e inexistente são ignoradas; sem login redireciona; o máximo 99.999.999,99 é aceito. O campo é `type="number"`, então o navegador manda ponto (`200.00`), nunca vírgula. Observação: notação científica (`1e3` = 1000) é aceita; é inofensivo.

**Decisão do responsável: vale o código.** A seção 3.3 e as figuras 6 e 7 modelam o limite com `meta_categorias` (`valor_maximo`, `valor_atual`, `id_meta_categoria` em `registro_financeiro` e em `categorias`). O código usa `limites_categoria` (um limite por usuário e por categoria, gasto calculado na hora), e o texto do RF 12 bate com ele. Então o diagrama e o DER é que se ajustam: sai `meta_categorias` e entra `limites_categoria`, e `id_meta_categoria` sai de `registro_financeiro` e de `categorias`. Sem mudança de código.

### 2.14 Erro de banco (RNF 04) – testado em 27/10

- O `Router` roda o controller dentro de `ob_start()` e de um `try/catch (PDOException)`. Em caso de erro de banco, descarta a saída parcial, responde **503** e mostra `views/erro/erro_banco.php` (mensagem clara, sem consultar o banco, com o tema do usuário se houver sessão). O detalhe técnico vai só para o log (`error_log`). [código]
- O `ConnectionFactory` **não imprime mais o erro bruto** (era a violação anotada na versão anterior). [código]
- Limite: só `PDOException` é tratada; outro tipo de exceção continua sem tratamento. [código]
- **Testado [testado] com o MariaDB desligado de verdade:** `/login`, `/logar`, `/dashboard`, `/transacoes`, `/ranking`, `/calculadoras`, `/admin` e o POST de salvar transação devolvem **503** com a tela "Não foi possível acessar o banco de dados" (pede para aguardar e tentar de novo, avisa para conferir se o registro foi salvo), página HTML completa e **sem vazar** SQLSTATE, caminho ou stack trace. Ao religar o banco o sistema volta sozinho e a sessão continua valendo. Um INSERT que falha no meio (gatilho forçado) também cai na mesma tela.
- Observação: o `migrate()` roda em toda requisição e **recria tabelas que sumirem** (`CREATE TABLE IF NOT EXISTS`), então apagar uma tabela com o banco no ar não gera erro, e sim uma tabela vazia.

### 2.15 Perfil (RF 04), senha e exclusão de conta – testado em 27/10

**O que o RF 04 exige e o código entrega [testado]:** o perfil mostra nome, nickname, e-mail, nível, XP, sequência atual, maior sequência e visibilidade no ranking; edita nome, nickname, telefone e foto; remove a foto; salva as preferências (visibilidade e modo escuro).

**Decisão que o código tomou:** o **usuário comum não altera e-mail nem data de nascimento** (valem os do banco, mesmo que venham no POST); só o administrador altera. Protege o RN 15 (idade mínima) e o RN 02. O texto do RF 04 diz apenas "dados pessoais", então vale registrar isso no capítulo 4. O responsável precisa confirmar que é isso que quer.

**Testado [testado]:** nickname de outro e nome vazio rejeitados; telefone inválido rejeitado e telefone vazio aceito; foto PNG válida salva; arquivo PHP disfarçado de `.png` e foto maior que 2 MB rejeitados; remover foto apaga do banco e do disco; perfil completo dá 20 XP uma vez (trocar a foto não repete); troca de senha (atual errada, nova igual à atual, confirmação diferente e nova vazia rejeitadas; a troca válida passa a valer e a senha antiga para de funcionar; a senha é gravada com bcrypt); exclusão de conta (RF 15 e RN 14): sem confirmação é recusada, com confirmação apaga o usuário, as transações, metas, parcelamentos, limites, histórico de XP e a foto do disco, e a pessoa não consegue mais entrar.

**Observações [testado], sem mudança de código:** (1) o cadastro aceita senha de **1 caractere** (não há tamanho mínimo; a troca de senha também só exige que seja diferente da atual); (2) o nome da foto é `usuario_<id>_<segundos>.<ext>`: se o usuário trocar a foto **duas vezes no mesmo segundo**, o arquivo novo recebe o mesmo nome e o código apaga "a foto antiga", ou seja, apaga a nova, e o banco aponta para um arquivo que não existe (improvável na prática; uma solução simples é incluir um número aleatório no nome).

### 2.16 Dashboard (RF 07) – implementado e testado em 27/10

**Como está no código [código]:** `DashboardController` e `DashboardService` (um mês por vez, escolhido por `?mes=AAAA-MM`, com setas de mês anterior e próximo; mês inválido, futuro ou anterior ao primeiro lançamento cai no mês atual), `views/dashboard/dashboard.php` e `public/assets/js/dashboard.js`.

- **Cartões:** saldo (no mês atual é o saldo de hoje; nos meses passados é o do último dia do mês), receitas, despesas e resultado do mês, com a variação em % contra os **mesmos dias do mês anterior** (nos meses fechados, contra o mês inteiro anterior).
- **Gráficos (Chart.js 4.5.1):** rosca de despesas por categoria (as 6 maiores e "Outras categorias", com o total no centro) e barras de receitas × despesas dos últimos 6 meses.
- **Painéis:** limites do mês por categoria (RF 12, os excedidos primeiro), até 4 metas (RF 06), parcelas do mês, últimos 5 lançamentos, gasto médio por dia, maior despesa do mês e estimativa de fechamento (só aparece depois do dia 7, porque nos primeiros dias a média engana). O aviso vermelho de RN 12 só aparece no mês atual. Nível, XP e streak continuam no topo (RF 05 e RF 09).
- Os dados dos gráficos vão no HTML como JSON (`dados-dashboard`) e o `dashboard.js` desenha em cima dele; Chart.js e Bootstrap vêm do CDN jsDelivr, então **a demonstração precisa de internet**.

**Testado [testado]** (usuário com dados do mês atual, do anterior e futuros): usuário novo sem dados abre sem erro; receitas R$ 1.000,00 e despesas R$ 450,00 (lançamentos futuros ficam fora); saldo acumulado R$ 750,00 (550 do mês + 200 do mês anterior); variação de +100% nas receitas e +50% nas despesas contra o mês anterior; o JSON da rosca soma 450 com Alimentação em 300; a evolução tem 6 meses (Mai/26 a Out/26, com 500/300 em setembro); mês anterior mostra receitas 500, despesas 300 e "Saldo no fim de Setembro" R$ 200,00; mês inválido (`abc`, `2099-01`, `2020-01`, `2026-13`, `2026-00`, `../../etc`, `<x>`, vazio e `mes[]`) cai no mês atual sem erro; sem login redireciona; limite excedido aparece no mês atual e some no mês passado; no máximo 4 metas; um usuário não vê os dados do outro; a descrição digitada com `<script>` não executa (o sistema grava o texto já escapado). **RNF 01:** com **8.000 lançamentos** o dashboard abre em **0,03 s** (mês atual e mês antigo). O `dashboard.js` passou na checagem de sintaxe do Node 22.

**Não testado:** o desenho dos gráficos no navegador (o ambiente de teste não tem navegador nem acesso ao CDN); só a sintaxe do JavaScript e o JSON foram conferidos.

**Observações [testado], sem mudança de código:** (1) o **administrador consegue abrir `/dashboard`** (vê um painel zerado) e até salvar uma transação, mesmo sem ter conta de usuário comum; o natural seria mandá-lo para `/admin`; (2) `/transacoes` **não tem paginação**: com 8.000 lançamentos a página tem 15 MB (0,11 s), o que não acontece com uso normal; (3) o saldo é **acumulado** (soma tudo até a data), por isso difere do resultado do mês.

### 2.17 Home page (Figura 8) e Demonstração – implementadas e testadas em 27/10

> **Atualizado em 03/11: a Demonstração foi removida do escopo** (decisão do responsável: o sistema não terá mais esse recurso). O que segue sobre `/demonstracao` fica só como histórico. No documento, tirar o botão do texto da Figura 8 (3.5) e da imagem.

**Decisões do responsável:** a Demonstração é uma **tela estática com números fictícios, sem banco, sem XP e sem salvar nada** (combina com a RN 11); quem já está logado e abre `/` vai direto para o painel (**usuário comum para `/dashboard`, administrador para `/admin`**).

**Como ficou [código]:** `HomeController` (`index` e `demonstracao`, sem services nem repositórios), rotas `GET /` e `GET /demonstracao` (a `/` deixou de apontar para o `DashboardController`; `/dashboard` continua igual), views `home/home.php` e `home/demonstracao.php`, `public/assets/css/home.css` e um link "Explorar sem login" e "Voltar ao início" na tela de login (Figura 9).

- **Home:** selo "Dream. Fund. Learn. Grow.", título "Transforme sonhos em realidade financeira", botões Entrar, Cadastrar, Começar agora e Demonstração, seis cartões de recursos (receitas e despesas, painel com gráficos, metas e limites, 10 calculadoras, extratos em PDF, tema claro e escuro), explicação da gamificação em 4 passos com o aviso de que o XP recompensa o hábito de uso e não os valores registrados, chamada final e rodapé do curso e do IFPR. Tema claro e escuro com botão (escolha guardada no navegador, padrão escuro como no protótipo).
- **Demonstração:** o mesmo desenho do dashboard (cartões com variação, rosca, evolução de 6 meses, ritmo do mês, limites com um exemplo excedido, metas, parcelas, últimos lançamentos), mais o ranking fictício e a tabela de como o XP é ganho. Faixa fixa avisando que é demonstração, sem formulário nenhum e com links só para `/`, `/login` e `/cadastrar`. Os números são fixos (receitas R$ 6.500,00, despesas R$ 4.150,00, nível 4 com 80/400 XP); só o nome do mês e os rótulos dos 6 meses seguem a data de hoje.
- Reaproveita o `dashboard.js` e as classes `dash-*` do dashboard; não há tabela, coluna nem migração nova.

**Testado [testado] (47 verificações, todas passaram):** `/` e `/demonstracao` abrem sem login e sem erro PHP, com os textos e botões do protótipo; sem `<form>`, `<input>`, `fetch` nem `action`; JSON dos gráficos coerente (rosca soma 4.150, resultado = receitas − despesas, último mês = mês atual); visitar as duas páginas não altera nenhuma tabela nem gera XP; usuário comum logado vai para `/dashboard` e administrador para `/admin`, tanto em `/` quanto em `/demonstracao`; conta bloqueada com sessão antiga é derrubada para o login; depois de sair, `/` mostra a home; **as duas páginas abrem com o banco desligado**; a RN 11 continua valendo nas 11 outras páginas testadas (dashboard, metas, transações, categorias, parcelamentos, ranking, calculadoras, relatórios, perfil, admin e lista de usuários); `POST` em `/` e `/demonstracao` não existe; o JavaScript embutido passou na checagem de sintaxe. Regressão: painel administrativo 35/35, limite por categoria e dashboard sem falha nova.

**Não testado:** o **visual** (o ambiente de teste não tem navegador nem acesso ao CDN do Bootstrap, Chart.js e ícones): layout, tema claro e escuro, celular e o desenho dos gráficos da demonstração. Vale o responsável abrir `/` e `/demonstracao` nos dois temas e no celular.

**Texto do documento (3.5):** a descrição da Figura 8 já bate com a home. Quando o capítulo 4 for escrito, a home e a demonstração podem entrar como telas reais, e a RN 11 vale para "qualquer outra página" (a home e a demonstração são as exceções públicas).


### 2.18 Travas de edição em metas e parcelamentos – feito e testado em 03/11

**Como está no código [código]:**

- **Metas (`MetaService::validar` e `updateMeta`, `MetaRepository::updateMeta`, `metas_edit.php`):** o valor alvo não pode ser menor que o valor já guardado na meta, que é o valor inicial somado aos aportes (`valor_atual`). Na criação, o "valor já guardado" não pode passar do valor alvo. Igual é aceito (a meta fica concluída). Na edição, o `valor_atual` usado é sempre o do banco, e o `UPDATE` só grava se `valor_alvo >= valor_atual` (protege contra um aporte gravado ao mesmo tempo). O campo na tela tem `min` igual ao já guardado e o aviso "O valor alvo não pode ficar abaixo disso".
- **Parcelamentos (`ParcelamentoService::updateParcelamento`, `ParcelaController::atualizar`, `parcelamentos_edit.php`):** a **data da 1ª parcela não pode ser editada**. O campo aparece desabilitado com o aviso "Não pode ser alterada depois do cadastro", e o servidor ignora qualquer data enviada e mantém a do banco. A **quantidade de parcelas não pode ficar abaixo das já pagas** (parcelas com vencimento até hoje), com a mensagem "A quantidade de parcelas não pode ser menor que as já pagas (N)". Igual às pagas é aceito (o parcelamento fica quitado). Continua valendo o mínimo de 2 parcelas (RN 13).

**Testado [testado]** (camada de serviço e repositório com SQLite em memória, porque o MariaDB não estava disponível nesta rodada; telas renderizadas): 33 verificações e 0 falhas. Metas: guardado maior que o alvo na criação recusado; guardado igual ao alvo aceito; meta com R$ 300 guardados e R$ 200 de aporte recusa alvo 499 e 400, aceita 500 (fica concluída) e 800; valor atual forjado no POST ignorado; meta de outro usuário recusada; o `UPDATE` direto no repositório com alvo abaixo do guardado não grava nada. Parcelamentos: 6x iniciado há 4 meses (5 pagas) recusa 4, aceita 5 (quitado) e 8 (8 registros, sem duplicar); data diferente enviada é ignorada e o 1º registro continua na data original; quantidade 1 e parcelamento de outro usuário recusados; com "lançar futuros" desligado (1 paga) aceita 2. **Falta repetir no MySQL real:** o caso de salvar a meta sem mudar nada (o MySQL devolve 0 linhas afetadas; o código confere de novo antes de acusar erro).


### 2.19 Parcelamento com lançamento manual ("Lançar parcela") e correção das lacunas – feito e testado em 03/11

**Decisão do responsável:** tirar a opção "lançar parcelas futuras" e deixar só um botão "Lançar parcela". As lacunas altas e médias levantadas na revisão do parcelamento foram corrigidas junto.

**Como está no código [código]:**

- **Cadastro** não lança nenhuma parcela. **Parcelas pagas = parcelas lançadas** (registros com `parcelamento_id`). A coluna `lancar_futuros` saiu do `script.sql` e do modelo; em bancos antigos ela continua existindo, sem uso.
- **Botão "Lançar parcela N/total"** (`POST /parcelamentos/lancar`): lança sempre a **próxima parcela da sequência**. Se ela já venceu, o registro entra na **data do vencimento**; se ainda não venceu (pagamento antecipado), entra com a **data de hoje**, e a tela pede confirmação avisando a data de vencimento. **Nunca existe registro de parcela com data futura.** Parcelamento quitado não lança mais nada.
- **Sem duplicidade:** coluna nova `registro_financeiro.numero_parcela` e chave única `uk_registro_parcela (parcelamento_id, numero_parcela)`. Dois cliques ao mesmo tempo não lançam a mesma parcela duas vezes (o botão também se desabilita ao enviar).
- **Botão "Desfazer"** (`POST /parcelamentos/desfazer`): remove só a **última parcela lançada**, com confirmação. Assim as parcelas ficam sempre em sequência, sem buracos.
- **Transações:** a parcela **não pode ser editada nem excluída** pela tela de Transações (service e SQL bloqueiam). Na lista aparece "Ver parcelamento" no lugar de Editar/Excluir.
- **Vencimentos sem passar do fim do mês:** compra no dia 31 vence em 28/02 (29/02 em ano bissexto), 31/03, 30/04 etc. (`Parcelamento::getDataVencimento`).
- **Vencidas sem lançar:** a lista mostra o aviso vermelho "N parcelas vencidas sem lançar". No dashboard, "A pagar neste mês" passa a calcular as parcelas **não lançadas que vencem até o fim do mês**, com as vencidas destacadas em vermelho; "já pagas no mês" são as lançadas com data no mês.
- **Edição:** a data da 1ª parcela continua travada; quantidade não pode ficar abaixo das lançadas (2.18). **Categoria, descrição e tag passam a valer também para as parcelas já lançadas.** O **valor novo vale só para as próximas**, porque as lançadas guardam o valor pago. **Valor total = já pago + valor atual × parcelas restantes.**
- **Descrição de cada parcela lançada:** "Descrição (N/total)", por exemplo "Notebook (3/10)". A tag não substitui mais a descrição no registro.
- **Exclusão do parcelamento:** as parcelas já lançadas **continuam nas transações como despesas comuns** (desvinculadas). Isso preserva o saldo e os relatórios dos meses passados. Para apagar também as lançadas, use "Desfazer" antes de excluir. A exclusão tem `try/catch` com `rollBack()`.
- **Validações novas, com mensagem na tela (antes falhavam sem aviso):** descrição obrigatória e com até 200 caracteres; tag com até 50; de 2 a 420 parcelas, em número inteiro; valor da parcela maior que zero; valor total de até R$ 99.999.999,99; data real (2026-02-30 é recusada) entre 01/01/2000 e 31/12/2099; a categoria precisa existir e ser de despesa (receita e "Metas" são recusadas). Se o banco recusar a gravação, aparece "Não foi possível salvar o parcelamento". O valor aceita vírgula.
- **Fuso horário:** a conexão faz `SET time_zone` com o fuso do PHP (America/Sao_Paulo). Antes, com o MySQL em UTC, o `CURRENT_DATE` já era "amanhã" a partir das 21h.
- **Migração (bancos antigos, roda uma vez em `migrarLancamentoManualDeParcelas`):** cria `numero_parcela`; **apaga as parcelas futuras geradas pela opção antiga** (eram só previsão); desvincula registros de parcelamentos que já não existem; numera as parcelas restantes pela data; cria a chave única.

**Testado [testado]** (camada de serviço, repositório e telas com SQLite em memória, porque o MariaDB não estava disponível nesta rodada): **61 verificações e 0 falhas.**
- **Datas:** 31/01 → 28/02 → 31/03 → 30/04; ano bissexto; virada de ano.
- **Validações:** 14 casos de recusa, sem gravar nada.
- **Lançamento:** o cadastro não lança nada; as vencidas entram na data do vencimento, numeradas e com "(N/total)"; a antecipada entra com a data de hoje; nenhuma parcela fica no futuro; parcelamento quitado recusa; a chave única barra a duplicada; outro usuário não lança nem desfaz.
- **Desfazer:** remove a última, e a próxima volta a ter o mesmo número.
- **Edição:** abaixo das pagas recusa; data forjada ignorada; as lançadas mantêm o valor e recebem a categoria e a descrição novas; o valor total e o "falta pagar" ficam corretos.
- **Transações:** a parcela é bloqueada no service e no SQL; uma despesa comum continua editável.
- **Dashboard:** mostra as vencidas sem lançar como "a pagar".
- **Exclusão:** as parcelas lançadas viram despesas comuns.
- **Telas:** lista, cadastro, edição e transações renderizam.

**Falta testar no MySQL real:**
1. A migração num banco antigo, que usa `ALTER ... AFTER` e `ADD UNIQUE KEY`, sintaxe que só existe no MySQL.
2. O `SET time_zone`.
3. O caso de salvar a meta sem mudar nada (2.18).

**Impacto no documento:**
- **RN 13** diz "as parcelas com vencimento até a data atual são consideradas pagas". Isso **não vale mais**: agora são pagas as parcelas lançadas pelo usuário. Ajustar o texto.
- **Diagrama e DER:** sai `lancar_futuros` e entra `numero_parcela` em `registro_financeiro`.
- **UC do parcelamento:** ganha os fluxos "lançar parcela" e "desfazer última parcela".


### 2.20 Responsividade para celular – feito e testado em 03/11

**Como está no código [código]:**

- **Menu (`partials/header.php`):** no computador (a partir de 992 px), os links continuam visíveis. No celular e no tablet, eles entram no **menu sanduíche**, acima de Perfil, Ranking, Relatórios e Sair; antes, quebravam em duas linhas fixas no topo. O link da página atual fica destacado nos dois casos.
- **Tabelas viram cartões no celular** (abaixo de 768 px), com a classe `tabela-cards` e `data-label` em cada célula: metas, transações, parcelamentos, categorias (limites), relatórios (extrato mensal e anual) e usuários do admin. Cada linha vira um cartão com o nome do campo à esquerda e os botões no fim. Em Finanças, a linha "Tipo" some no celular, porque a cor e o sinal do valor já mostram isso. O ranking ficou como tabela, porque já cabia.
- **Cabeçalhos das páginas** (classe `cabecalho-pagina`, em 26 telas): o título e os botões quebram linha em vez de espremer. No celular, um grupo de botões (ex.: Perfil) desce inteiro para a linha de baixo.
- **Ajustes de celular (`style.css`, abaixo de 576 px):** títulos menores, menos espaço interno nos cartões, logo menor e gráficos do dashboard mais baixos.
- **Correção de visual (não só de celular):** no **tema claro**, o topo do dashboard tinha texto branco sobre fundo quase branco e ficava ilegível. Agora ele é sempre escuro; no tema escuro continua como antes.
- **Parcelamentos:** um rótulo oculto no cabeçalho da tabela fazia a página inteira rolar para o lado no tablet. Foi trocado por `aria-label`.

**Testado [testado]:** o sistema rodou com banco de teste e foram tirados prints de 30 telas em 390 px (celular), além de verificações em 768, 820, 1024 e 1366 px. Nenhuma página passa da largura da tela e nenhuma tabela precisa de rolagem lateral no celular. O menu abre com os links; o modo escuro e o computador ficaram sem regressão. Os gráficos (Chart.js) e os ícones não foram vistos nos prints, porque o ambiente de teste não acessa a CDN.

### 2.21 Limpeza de código morto e limite de senha – feito em 03/11

**Código morto removido** (conferido por busca em todo o projeto; nenhum era chamado): `CategoriaService::existeCategoria`, `Categoria::getIcone` e `getLimiteOrcamento`, `Transacao::getMetaId` e `getParcelamentoId`, `Usuario::setCriadoEm`, `Parcelamento::eProximaAtrasada`, `Router::getAllRoutes`, o `use Exception` do Router e as classes CSS `.auth-body`, `.btn-auth` e `.home-rodape-separador`. Mantidos de propósito: `erro_banco.php` (usado pelo Router) e `Header`/`Footer` do extrato (sobrescrevem o FPDF).

**Limite de senha:** mínimo de **8 caracteres** e máximo de **72 bytes** (o bcrypt ignora o que passa de 72 bytes, então senhas maiores seriam cortadas sem aviso). Vale no cadastro, na criação de administrador e na troca de senha, com validação no servidor (`UsuarioService`) e `minlength`/`maxlength` nos formulários. O **login não tem limite**, para quem já tem conta com senha curta continuar entrando. [testado: limites 7/8/72/73 bytes e acentos; formulários só lidos]

### 2.22 Metas: transferência entre saldo e meta (aporte, resgate e exclusão) – feito em 03/11

**Regra nova (muda o RF 14 do documento):** aporte e resgate são **transferências**, não despesa nem receita. O aporte tira do saldo e põe na meta; o **resgate** (botão "Resgatar" em Metas) tira da meta e devolve ao saldo, até o valor guardado; ao **excluir a meta, todo o valor guardado volta para o saldo**.

**Como ficou:** o aporte continua gravado como registro na categoria "Metas" e o resgate como registro na categoria nova "Resgate de metas" (receita), os dois ligados à meta. Esses registros **ficam fora** de receitas, despesas, gráfico por categoria, maior despesa, comparação e evolução do painel, mas **entram no saldo**, nas listas (Transações, últimas do painel) e no **extrato** (que mostra a movimentação completa da conta, então receitas e despesas do extrato incluem essas transferências). Na tela de Transações, aporte e resgate não são editados nem excluídos ("Ver metas"); a única saída do dinheiro da meta é o resgate ou a exclusão da meta.

**Exclusão:** os registros da meta saem (o saldo volta ao que era antes dos aportes e resgates) e o valor inicial da meta, que nunca saiu do saldo, entra como **uma receita** em "Outras receitas" ("Valor inicial da meta excluída: nome"). Resultado: o saldo sobe exatamente o valor guardado. Meta concluída aceita resgate e volta a aceitar aporte.

**Migração:** `DatabaseInitializer` cria a categoria "Resgate de metas" em bancos existentes; aportes antigos já ficam fora dos totais (a regra é pelo vínculo com a meta). [testado em SQLite: 31 verificações; MySQL real e telas no navegador não testados]

### 2.23 Filtros de Minhas Finanças (/transacoes) – feito em 03/11

Além de tipo e categoria, a lista agora filtra por **período** (de/até, com atalhos Este mês, Mês passado, Últimos 30 dias e Este ano), **faixa de valor** (mínimo e máximo), **busca** na descrição ou categoria, **origem** (lançadas por mim, parcelas, metas) e **ordenação** (recentes, antigas, maior e menor valor). Os filtros ativos aparecem como chips que se removem um a um, a lista mostra a quantidade e as somas do que está na tela (aportes e resgates de meta não entram nas somas) e, no celular, o painel de filtros recolhe. Valores inválidos na URL (data impossível, período invertido, valor negativo ou mínimo maior que o máximo) são ignorados com um aviso; a busca aceita até 100 caracteres e trata `%` e `_` como texto. Os cartões do topo continuam com os totais gerais. [testado: 34 verificações em SQLite e telas em desktop e celular com SQLite; MySQL real não testado]

### 2.24 Avisos de XP/nível e dados de demonstração – feito em 04/11

**CSRF:** decidido não implementar (o sistema não vai para a web; fora do escopo do PI).

**Avisos de XP e nível.** `GamificacaoService::concederXp` deixa na sessão (`notificacoes_xp`) o XP ganho, o nome da ação e, se subiu, o novo nível. O cabeçalho (`partials/notificacao_xp.php`) mostra um toast do Bootstrap no canto inferior direito e apaga o aviso, então ele aparece uma única vez, também quando o XP é ganho antes de um redirecionamento. Subir de nível aparece em verde ("Você subiu para o nível N!"). [testado em navegador com SQLite: o login da conta de demonstração mostra "nível 3" e "+5 XP · Acesso diário"; ao recarregar não repete]

**Dados de demonstração.** `php app/database/scripts/dados_demonstracao.php` (só por linha de comando) recria a conta `demo@dflg.com` (senha `Demo@2026`) com seis meses de receitas e despesas, três metas com aportes e um resgate, dois parcelamentos já lançados em parte, limites por categoria (o de Lazer já estourado no mês, para aparecer o aviso do RF 12) e 295 XP no nível 2 com sequência de 12 dias e último acesso ontem: o primeiro login do dia soma 5 XP e sobe para o nível 3. Rodar de novo apaga só essa conta e a recria. Não é a "Demonstração" da 2.17 (removida): é um recurso de apresentação, fora do sistema. [testado em SQLite; MySQL real não testado]

**Limite de tentativas de login:** descartado (ver 2.25).

### 2.25 Redefinição de senha pelo administrador – feito em 04/11

Como o sistema não tem "esqueci minha senha", o administrador redefine a senha de quem a perdeu: em **Editar conta** há o bloco "Redefinir senha" (nova senha e confirmação, de 8 a 72 caracteres, com confirmação no navegador). A senha anterior não é pedida; a nova é gravada com bcrypt e o administrador a informa à pessoa, que pode trocá-la depois em Perfil. A permissão é a mesma de editar e bloquear (2.8): o chefe redefine a de administradores comuns e usuários comuns, o administrador comum só a de usuários comuns, ninguém redefine a própria senha por ali nem a do chefe (o chefe troca a dele em Perfil). Rota `POST /admin/usuarios/senha`. Por causa dessa recuperação, o **limite de tentativas de login** (bloqueio) foi descartado: o projeto não terá bloqueio por tentativas. **Para o documento:** acrescentar "redefinir senha" às ações do RF 02. [testado em SQLite: senha curta e confirmação diferente recusadas; a senha antiga deixa de entrar e a nova entra; tentar redefinir a do chefe e usuário comum chamando a rota são barrados; MySQL real não testado]

## 3. Pendências (decidir antes de implementar)

| Item | Descrição |
|---|---|
| **Parcelamento** | O vínculo está decidido (segue o código, 2.3). Falta decidir o que fazer com os pontos conhecidos. |
| **Confirmar as decisões do código no RF 01 e RF 02 e no perfil** | Ver as seções 2.8 e 2.15 (inclui o chefe poder excluir contas, que o RF 02 não cita, e o e-mail/nascimento travados para o usuário comum). |

| **Itens do documento** | Ver a lista "O que mudar no documento" na seção 3.1. |

**Resolvidos e testados em 27/10:** home page e demonstração (2.17); dashboard com gráficos e RNF 01 (2.16); chefe em banco novo (2.8); link "Categorias" no menu; confirmação ao sair; bloqueados e quem oculta a visibilidade fora do ranking, nas três abas (2.11); streak efetivo na exibição e no desempate (2.4); RNF 04 (2.14); RF 12 (2.13); RF 01 e RF 02 (2.8); RF 04 (2.15); "Valor já guardado" só na criação (2.12); exclusão do parcelamento (2.3).

### 3.1 O que mudar no documento (PDF `-7` de 27/10/2026)

**Já aplicado no PDF `-6`:** seção 2.3.2 com RF04; RN 11 sem verbo repetido; "calculadoras" no texto; Figura 7 na Lista de Ilustrações; seção 2.3 sem a remissão à 2.1; texto da 3.3 (associações de `registro_financeiro`, `limites_categoria` e `parcelamentos`, sem `meta_categorias`); texto da 3.4 (`LimiteCategoria` e `Parcelamento`); Resumo reescrito; ANDERSON e PRESSMAN; MAXIM citados; "Acesso em:" da REVISTA ARCO corrigido; título da 3.2 na página 28.

**Corrigido no PDF `-7`:** Resumo ("Nesta etapa, já estão..."); 1.4.1 (Kanban e a frase única); 1.4.2 ("no qual"); espaço na 3.3; 3.4 com "o nível e a visibilidade no ranking".

**Sumário:** o responsável informou que já ajustou (não conferido no PDF, que ele não reenviou).

**Ainda a fazer:**

1. **Figura 6 (diagrama de classes) e Figura 7 (DER)** continuam antigas e ficaram atrás do texto: `historico_xp`, `limites_categoria`, parcelamento como no código (2.3), `foto`, `status`, `maior_streak` (Figura 7) entram; `meta_categorias`, `simulacoes_investimento`, `data_ultimo_xp` e `id_meta_categoria` saem. `nivel_permissao` já está implementado (1 = chefe, 2 = administrador comum; dizer isso no texto da 3.3) e `telefone` (VARCHAR(11), opcional) entra em `usuarios`, porque o código passou a ter. `parcelas_pagas` não entra.
3. **3.3 (usuarios e administradores):** acrescentar `telefone` (opcional) à lista de atributos de `usuarios` e dizer que `nivel_permissao` vale 1 para o chefe e 2 para o administrador comum (o texto já cita o atributo).
4. **3.5 (protótipos):** a Figura 10 ("gráficos dinâmicos") **agora é verdadeira**, porque o dashboard tem rosca e barras; a Figura 12 ainda mostra "simulador" (só a imagem, opcional). A Figura 8 (home) agora existe (2.17).
7. **RF 02 (opcional):** o texto diz "editar, bloquear, desbloquear" e o código também deixa o chefe excluir contas (2.8); decidir se se acrescenta "excluir" ou se a diferença fica como está.
5. **Capítulos 4 e 5:** o responsável só fará depois que **todos os requisitos estiverem prontos** (telas reais, 4.2 com a pesquisa e a tabela de requisitos por tela, Considerações Finais; apagar os textos-guia do modelo).
6. **Resumo:** reler no fim; já pode citar o dashboard com gráficos, o painel administrativo e a home page (quando existir).

## 4. Estado do sistema (conferido e testado no zip de 27/10/2026)

| RF | Estado | Observação |
|---|---|---|
| RF 01 | **Feito e testado**, com **um bug em banco novo** | Cadastro comum (RN 02, RN 15) e criação de administrador só pelo chefe (RN 01). Ver 2.8: o admin do script nasce nível 2. |
| RF 02 | **Feito e testado** | Painel com indicadores, lista, busca, bloqueio, desbloqueio, edição e exclusão (2.8). |
| RF 03 | Feito e testado | Login recusa bloqueado; sessão aberta cai no próximo clique. |
| RF 04 | **Feito e testado** | Ver 2.15 (e-mail e nascimento travados para o usuário comum). |
| RF 05 | Feito e testado | Acesso diário, marcos, calculadoras, perfil completo, preferências e relatórios dão XP; nível 100 + 200 +... confere. |
| RF 06 | Feito e testado | CRUD de metas, tipos e RN 08 (data tem que ser posterior a hoje). "Valor já guardado" só na criação; aceita valor maior que o alvo (observação). |
| RF 07 | **Feito e testado** | CRUD, categorias, filtros, RN 05 e RN 06, e agora o dashboard completo (2.16): cartões, rosca, evolução de 6 meses, limites, metas, parcelas, ritmo e navegação por mês. Observações na 2.16 (administrador abre `/dashboard`, `/transacoes` sem paginação). |
| RF 08 | Feito e testado | 10 calculadoras, exigem login (RN 11), 10 XP por dia (RN 07), não gravam simulação. |
| RF 09 | Feito e testado | Ver 2.4 (exibição e desempate usam o streak efetivo). |
| RF 10 | **Feito e testado** | Ver 2.11. Bloqueados e ocultos ficam fora nas três abas. |
| RF 11 | **Feito e validado** | Ver 2.10 (o PDF não foi reaberto nesta rodada). |
| RF 12 | **Feito e testado** | Ver 2.13. Vale o código (`limites_categoria`); o documento se ajusta. |
| RF 13 | Feito no modelo B e testado | RN 13 ok (1 parcela, valor 0 e data vazia rejeitados); falha na exclusão não perde dados (2.3). |
| RF 14 | **Feito e testado** | Ver 2.12; aporte maior que o saldo é recusado e apagar o lançamento do aporte devolve o valor da meta. |
| RF 15 | Feito e testado | Só usuário comum, com confirmação; apaga todos os dados e a foto (2.15). |
| RNF 01 | **Atendido nos testes** | Dashboard em 0,03 s e relatórios abaixo de 0,05 s, com 8.000 lançamentos (2.10 e 2.16). Os gráficos existem agora. |
| RNF 04 | **Feito e testado** | Ver 2.14 (testado com o banco desligado). |
| RNF 07 | Feito e validado | Ver 2.6. |

## 5. Pontos técnicos conhecidos

- Todas as exclusões (metas, transações, parcelamentos, conta) são feitas por **POST** (`GET /perfil/excluir` só mostra a tela de confirmação). Não há proteção CSRF (nenhum token nas rotas ou formulários). [código]
- `categorias` é uma tabela global, sem dono (todo usuário vê as mesmas categorias). [código]
- A senha do admin de teste está em comentário no `script.sql` (aceitável em desenvolvimento).
- As migrações ficam no `DatabaseInitializer` (`migrarColunasAntigas`, `migrarColunasParcelamento`, `migrarColunaTema`, `migrarAporteMeta`, `migrarLimiteCategoria`). O `script.sql` não tem `ALTER TABLE` soltos. [código]
- `migrate()` roda a cada requisição (consultas ao `information_schema` e à tabela de categorias em toda página). Funciona, mas é trabalho repetido, e cresce a cada migração nova. [código]
- O script deve rodar uma vez, em banco vazio. Reexecutar duplica categorias (a tabela `categorias` não tem chave única no nome) e o `INSERT IGNORE` do admin depende da chave única do e-mail. [relato quanto à duplicação]
- O login já usa `session_regenerate_id(true)`. [código]
- O `Autoload.php` lança exceção para qualquer classe fora do namespace `app\` (motivo de a FPDF ser carregada por `require_once`). Bibliotecas novas com autoload próprio exigiriam mexer nele.
- `app/libs/fpdf/` é código de terceiros, sem alteração; não editar. O acesso direto a `app/` pela web é bloqueado pelo `.htaccess` da raiz. [código]
- Na view do ranking, `$descricao` é impresso sem `htmlspecialchars`, mas é montado só por datas e nomes de mês fixos (sem risco hoje). [código]

## 6. Próximos passos

Todos os 15 RF, os 7 RNF e a home page estão no código. Falta:

1. **Abrir `/` e `/demonstracao` no navegador**, nos temas claro e escuro e no celular (o visual não foi testado, 2.17).
2. Confirmar as decisões do código no RF 01, RF 02 e no perfil (seções 2.8 e 2.15) e, se quiser, mandar o administrador de `/dashboard` para `/admin` (2.16).
3. Fechar A, desenhar e aprovar o DER e o diagrama de classes (já com `limites_categoria`, o parcelamento como no código, `telefone` e `nivel_permissao`) e refazer as figuras 6 e 7 (seção 3.1).
4. Aplicar no PDF o resto da lista da seção 3.1; depois, os **capítulos 4 e 5** (agora que todas as telas existem, com as telas reais, a pesquisa de satisfação e a tabela de requisitos por tela).
5. Opcionais: nome de foto único; paginação em `/transacoes`; `try/catch` com `rollBack()` na exclusão do parcelamento.


## 7. Resultado dos testes de 27/10/2026

Ambiente: PHP 8.3.6 (servidor embutido) e MariaDB 10.11, banco criado do zero pelo próprio sistema, requisições HTTP reais (sessão, formulários, upload de imagem). Foram seis baterias.

| Área | Itens | Resultado |
|---|---|---|
| Painel administrativo (RF 01, RF 02, RN 01, RN 02, RN 09, RN 14, RN 15) | 35 | **35 passaram** no zip de 27/10 (o bug do chefe em banco novo foi corrigido; na rodada anterior eram 34 de 35) |
| Home e Demonstração (Figura 8, RN 11) | 47 | passou tudo; o visual não foi testado |
| Dashboard (RF 07, RNF 01, RN 12) | 36 | passou tudo que o sistema deveria fazer (as falhas dos testes foram de expectativa: o saldo é acumulado e a descrição é gravada escapada) |
| Regressão (limite, ranking/streak/XP, parcelamento/metas) | 68 | mesmo resultado da rodada anterior, sem falha nova |
| Limite por categoria (RF 12, RN 12) | 29 | passou tudo que o sistema deveria fazer; 2 falhas do **teste** (formato de número do teste e notação científica aceita, sem problema) |
| Ranking, streak, XP e nível (RF 05, RF 08, RF 09, RF 10) | 22 | passou tudo (1 falha do teste: o pódio mostra o 2º lugar antes do 1º) |
| Parcelamento e metas (RF 06, RF 13, RF 14) | 17 | passou tudo (1 falha do teste: o registro da parcela leva a tag como descrição) |
| Perfil, senha, foto e exclusão (RF 04, RF 15, RN 14) | 32 | 31 passaram; **1 caso de borda real**: duas trocas de foto no mesmo segundo |
| Banco fora do ar (RNF 04) | 28 | 26 passaram; as 2 falhas são do teste (o `migrate()` recria tabela apagada) |

**Não testado nesta rodada:** o desenho dos gráficos no navegador (só o JSON e a sintaxe do JavaScript), o conteúdo do PDF de extrato (RF 11, já validado pelo responsável), o aspecto visual do modo escuro e a responsividade (RNF 06 e 07) e CSRF (não existe proteção, 5).

**Todos os achados reais:** (1) bug do chefe em banco novo; (2) foto trocada no mesmo segundo; (3) senha sem tamanho mínimo (**resolvido em 03/11, 2.21**); (4) meta aceita valor já guardado maior que o alvo (**resolvido em 03/11, 2.18**); (5) o chefe excluir contas vai além do texto do RF 02; (6) a exclusão do parcelamento depende de rollback implícito; (7) o administrador abre `/dashboard` e salva transação sem ser usuário comum; (8) `/transacoes` sem paginação.

## 8. Como retomar em um chat novo

Anexe: este arquivo, o `PROMPT_CLAUDE.md`, o PDF do documento do PI e o zip mais recente do projeto. Peça para a IA ler tudo, **comparar o zip com o que este arquivo descreve** e confirmar as regras de trabalho (seção 1) antes de começar. A IA deve apontar o que estiver diferente do que está aqui, e nunca decidir sozinha.