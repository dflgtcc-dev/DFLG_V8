<?php
// RNF 07: aplica o tema escolhido pelo usuário (claro ou escuro) em todas as telas internas
$temaBootstrap = $_SESSION['usuario_logado']->getTema() === 'escuro' ? 'dark' : 'light';
$ehAdmin = $_SESSION['usuario_logado']->eAdmin();
?>
<script>
    document.documentElement.setAttribute('data-bs-theme', '<?= $temaBootstrap ?>');
</script>
<nav class="navbar navbar-dflg mb-4 sticky-top" data-bs-theme="dark">
    <div class="container">
        <a href="<?= URL_BASE ?><?= $ehAdmin ? '/admin' : '/dashboard' ?>" class="navbar-brand mb-0 h1 text-white text-decoration-none">
                <img src="<?= URL_BASE ?>/assets/img/logo-dflg-transparent.png" alt="DFLG" height="36" class="me-2">Investments
        </a>

        <!-- Links (sempre visíveis, à direita) + menu sanduíche -->
        <div class="d-flex align-items-center gap-2">
            <div class="nav-links">
                <?php if ($ehAdmin): ?>
                    <a href="<?= URL_BASE ?>/admin" class="nav-link-dflg">Painel</a>
                    <a href="<?= URL_BASE ?>/admin/usuarios" class="nav-link-dflg">Usuários</a>
                <?php else: ?>
                    <a href="<?= URL_BASE ?>/dashboard" class="nav-link-dflg">Dashboard</a>
                    <a href="<?= URL_BASE ?>/metas" class="nav-link-dflg">Metas</a>
                    <a href="<?= URL_BASE ?>/transacoes" class="nav-link-dflg">Finanças</a>
                    <a href="<?= URL_BASE ?>/parcelamentos" class="nav-link-dflg">Parcelamentos</a>
                    <a href="<?= URL_BASE ?>/categorias" class="nav-link-dflg">Categorias</a>
                    <a href="<?= URL_BASE ?>/calculadoras" class="nav-link-dflg">Calculadoras</a>
                <?php endif; ?>
            </div>

            <!-- Menu sanduíche: Perfil, Ranking, Relatórios e Sair -->
            <div class="dropdown">
            <button class="btn-sanduiche" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Abrir menu">
                <i class="bi bi-list"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end dropdown-dflg">
                <li><a class="dropdown-item" href="<?= URL_BASE ?>/perfil"><i class="bi bi-person me-2"></i>Perfil</a></li>
                <?php if (!$ehAdmin): ?>
                    <li><a class="dropdown-item" href="<?= URL_BASE ?>/ranking"><i class="bi bi-trophy me-2"></i>Ranking</a></li>
                    <li><a class="dropdown-item" href="<?= URL_BASE ?>/relatorios"><i class="bi bi-file-earmark-text me-2"></i>Relatórios</a></li>
                <?php endif; ?>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item text-danger" href="<?= URL_BASE ?>/logout"
                       onclick="return confirm('Deseja realmente sair da conta?');">
                        <i class="bi bi-box-arrow-right me-2"></i>Sair
                    </a>
                </li>
            </ul>
            </div>
        </div>
    </div>
</nav>